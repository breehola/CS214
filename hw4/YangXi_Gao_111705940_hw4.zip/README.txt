Hw4. 

--------------------
Q1.
In1.java (run this one)
	-Scanner getInput(String txt)
	-String twoSum(int num, int targetSum, int[] arr, HashMap<Integer, Integer> given)
	-void main(String [] args)

in1.txt
	-input file 
	-format: 
		4 9 (number_of_elements target_number)
		2 7 11 15 (elements)

--------------------
Q2.
In2.java (run this one)
	-Scanner getInput(String txt)
	-int sumOfThree(int size, int mysticalCon, int[] valueArr)
	-void main(String [] args)

in2.txt
	-input file
	-format:
		10 5 (number_of_elements magical_constant)
		1 10 4 3 2 5 0 1 9 5 (elements)
