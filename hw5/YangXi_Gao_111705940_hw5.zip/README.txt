Hw5. 

In1.java
	-Scanner getInput(string txt)
	-void print(int[][] given) -prints 2-D array, exists solely for the purpose of debugging
	-boolean isPath(int[][] pris, int x, int y) -returns true if pris[x][y] is a valid path, false otherwise
	-int numberOfPaths(int[][] given, int x, int y, int n) -finds number of solution paths in a 2-D array
	-void main(String [] args)

in1.txt
	formatted:
		m (number of test cases)
		n 
		[square 2-D array n-by-n of 1's and 0's]

	-do not leave blank lines
	-one space between digits in matrix
	-ex. 
		0 1 1 0 
		0 0 1 0
		0 0 0 0
		0 1 1 0